# LA Uniformes - Multi-loja (final)

Sistema local simples com:
- multi-loja (stores)
- usuários por loja (admin/funcionario)
- produtos, pedidos, financeiro
- admin pode criar funcionários e gerenciar finanças

## Como rodar

1. Instale Node.js (LTS)
2. Abra o terminal na pasta do projeto
3. Rode:
   ```
   npm install
   npm start
   ```
4. Acesse: http://localhost:4000

Usuários admin padrões (se não alterados):
- admin.centro@la.com / 123456 (Loja 1)
- admin.norte@la.com / 123456 (Loja 2)
- admin.sul@la.com / 123456 (Loja 3)

Observações:
- Em produção, troque a SECRET (JWT) e use um banco adequado (Postgres).
- Faça backup do arquivo data.db regularmente.

