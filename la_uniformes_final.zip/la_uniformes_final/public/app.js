// Frontend JS - minimal and clear for employees
let token = null;
let userRole = null;
let storeId = null;
let storeName = '';

async function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const res = await fetch('/api/login', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({email, password})
  });
  const data = await res.json();
  if(data.error) return alert(data.error);
  token = data.token;
  userRole = data.role;
  storeId = data.store_id;
  // get stores to find name
  const storesRes = await fetch('/api/stores');
  const stores = await storesRes.json();
  const store = stores.find(s=>s.id === storeId) || {};
  storeName = store.name || ('Loja ' + storeId);
  document.getElementById('login').style.display = 'none';
  document.getElementById('main').style.display = 'block';
  document.getElementById('storeName').innerText = `🏪 ${storeName} — ${userRole.toUpperCase()}`;
  // show admin controls
  if(userRole === 'admin'){
    document.getElementById('adminControls').style.display = 'block';
    document.getElementById('adminControls2').style.display = 'block';
    document.getElementById('adminPanel').style.display = 'block';
    document.getElementById('financeSection').style.display = 'block';
    showAdminPanel();
    loadFinance();
  } else {
    document.getElementById('adminControls').style.display = 'none';
    document.getElementById('adminControls2').style.display = 'none';
    document.getElementById('adminPanel').style.display = 'none';
    document.getElementById('financeSection').style.display = 'none';
  }
  loadProducts();
}

function logout(){
  token = null; userRole = null; storeId = null;
  document.getElementById('login').style.display = 'block';
  document.getElementById('main').style.display = 'none';
  document.getElementById('userPanel').style.display = 'none';
}

async function loadProducts(){
  const res = await fetch('/api/products', { headers: { Authorization: token }});
  const data = await res.json();
  const list = document.getElementById('products');
  list.innerHTML = '';
  data.forEach(p=>{
    const li = document.createElement('li');
    li.innerHTML = `#${p.id} — <strong>${p.name}</strong> — R$ ${Number(p.price).toFixed(2)} — Estoque: ${p.stock}`;
    list.appendChild(li);
  });
}

async function addProduct(){
  const name = prompt('Nome do produto:');
  const price = parseFloat(prompt('Preço:'));
  const stock = parseInt(prompt('Quantidade inicial:'));
  if(!name) return;
  const res = await fetch('/api/products', { method: 'POST', headers: {'Content-Type':'application/json','Authorization':token}, body: JSON.stringify({name, price, stock})});
  const data = await res.json();
  if(data.error) return alert(data.error);
  alert('Produto criado!');
  loadProducts();
}

async function registerOrder(){
  const id = parseInt(prompt('ID do produto:'));
  const qty = parseInt(prompt('Quantidade:'));
  if(!id || !qty) return;
  const res = await fetch('/api/orders', { method: 'POST', headers: {'Content-Type':'application/json','Authorization':token}, body: JSON.stringify({product_id:id, quantity:qty})});
  const data = await res.json();
  if(data.error) return alert(data.error);
  alert('Pedido registrado! Total R$ ' + (data.total||0));
  loadProducts();
  if(userRole === 'admin') loadFinance();
}

// Admin panel
function showAdminPanel(){
  const panel = document.getElementById('adminPanel');
  panel.innerHTML = `<h3>⚙️ Painel Administrativo</h3>
    <button onclick="openUserPanel()">👥 Gerenciar Funcionários</button>
    <button onclick="promptAddProduct()">➕ Adicionar Produto</button>
    <button onclick="promptAddFinance()">💸 Lançar Financeiro</button>
    <div id="adminMessages"></div>`;
}

function promptAddProduct(){ addProduct(); }
function promptAddFinance(){ addFinance(); }

async function loadFinance(){
  const res = await fetch('/api/finance', { headers: { Authorization: token }});
  const rows = await res.json();
  const list = document.getElementById('finance');
  list.innerHTML = '';
  let total = 0;
  rows.forEach(r=>{
    const li = document.createElement('li');
    li.innerText = `${r.date.slice(0,10)} — ${r.type} — ${r.description} — R$ ${Number(r.amount).toFixed(2)}`;
    list.appendChild(li);
    total += (r.type === 'receita') ? Number(r.amount) : -Number(r.amount);
  });
  document.getElementById('balance').innerText = '💵 Saldo: R$ ' + total.toFixed(2);
}

async function addFinance(){
  const type = prompt('Tipo (receita/despesa):');
  const description = prompt('Descrição:');
  const amount = parseFloat(prompt('Valor:'));
  if(!type || !description || isNaN(amount)) return;
  const res = await fetch('/api/finance', { method:'POST', headers:{'Content-Type':'application/json','Authorization':token}, body: JSON.stringify({type,description,amount})});
  const data = await res.json();
  if(data.error) return alert(data.error);
  alert('Lançamento salvo');
  loadFinance();
}

// === User management ===
function openUserPanel(){
  document.getElementById('userPanel').style.display = 'block';
  loadUsers();
}
function closeUserPanel(){ document.getElementById('userPanel').style.display = 'none'; }
async function loadUsers(){
  const res = await fetch('/api/users', { headers: { Authorization: token }});
  const rows = await res.json();
  const list = document.getElementById('userList');
  list.innerHTML = '';
  rows.forEach(u=>{
    const li = document.createElement('li');
    li.innerText = `${u.email} — ${u.role.toUpperCase()}`;
    list.appendChild(li);
  });
}
async function createUser(){
  const email = document.getElementById('newUserEmail').value;
  const password = document.getElementById('newUserPass').value;
  const role = document.getElementById('newUserRole').value;
  if(!email || !password) return alert('Preencha todos os campos');
  const res = await fetch('/api/users', { method:'POST', headers:{'Content-Type':'application/json','Authorization':token}, body: JSON.stringify({email,password,role})});
  const data = await res.json();
  if(data.error) return alert(data.error);
  alert('Usuário criado');
  document.getElementById('newUserEmail').value = '';
  document.getElementById('newUserPass').value = '';
  loadUsers();
}
