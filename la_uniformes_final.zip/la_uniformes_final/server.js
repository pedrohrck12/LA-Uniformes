const express = require("express");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const sqlite3 = require("sqlite3").verbose();
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

const SECRET = process.env.JWT_SECRET || "la_uniformes_secret_change_me";
const db = new sqlite3.Database("./data.db");

// Create tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS stores (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE,
      password TEXT,
      role TEXT,
      store_id INTEGER
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      price REAL,
      stock INTEGER,
      store_id INTEGER
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER,
      quantity INTEGER,
      total REAL,
      date TEXT,
      store_id INTEGER
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS finance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT,
      description TEXT,
      amount REAL,
      date TEXT,
      store_id INTEGER
  )`);

  db.all(`SELECT * FROM stores`, (err, rows) => {
    if (!rows || rows.length === 0) {
      db.run(`INSERT INTO stores (name) VALUES ('Loja Centro')`);
      db.run(`INSERT INTO stores (name) VALUES ('Loja Norte')`);
      db.run(`INSERT INTO stores (name) VALUES ('Loja Sul')`);
      console.log("✅ Lojas criadas: Centro, Norte e Sul");

      // create admins
      createAdmin("admin.centro@la.com", "123456", 1);
      createAdmin("admin.norte@la.com", "123456", 2);
      createAdmin("admin.sul@la.com", "123456", 3);
    }
  });
});

function createAdmin(email, senha, store_id) {
  bcrypt.hash(senha, 10, (err, hash) => {
    if(err) return console.error(err);
    db.run(
      `INSERT OR IGNORE INTO users (email, password, role, store_id) VALUES (?, ?, ?, ?)`,
      [email, hash, "admin", store_id],
      (e) => { if(e) console.error(e); else console.log(`👤 Admin criado: ${email} (Loja ${store_id})`); }
    );
  });
}

// Middlewares
function auth(req, res, next) {
  const token = req.headers["authorization"];
  if (!token) return res.status(401).json({ error: "Token obrigatório" });
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ error: "Token inválido" });
    req.user = decoded;
    next();
  });
}

function adminOnly(req, res, next) {
  if (!req.user || req.user.role !== "admin")
    return res.status(403).json({ error: "Acesso restrito ao administrador" });
  next();
}

// Routes

// Login
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  db.get(`SELECT * FROM users WHERE email = ?`, [email], (err, user) => {
    if (err) return res.status(500).json({ error: "Erro no servidor" });
    if (!user) return res.status(400).json({ error: "Usuário não encontrado" });
    bcrypt.compare(password, user.password, (err, ok) => {
      if (err) return res.status(500).json({ error: "Erro no servidor" });
      if (!ok) return res.status(400).json({ error: "Senha incorreta" });
      const token = jwt.sign(
        { id: user.id, role: user.role, store_id: user.store_id, email: user.email },
        SECRET,
        { expiresIn: "8h" }
      );
      res.json({ token, role: user.role, store_id: user.store_id, email: user.email });
    });
  });
});

// list stores
app.get("/api/stores", (req, res) => {
  db.all(`SELECT * FROM stores`, (err, rows) => {
    if (err) return res.status(500).json({ error: "Erro ao listar lojas" });
    res.json(rows || []);
  });
});

// Users (admin only)
app.post("/api/users", auth, adminOnly, (req, res) => {
  const { email, password, role } = req.body;
  if (!email || !password || !role) return res.status(400).json({ error: "Campos obrigatórios" });
  bcrypt.hash(password, 10, (err, hash) => {
    if (err) return res.status(500).json({ error: "Erro hashing senha" });
    db.run(
      `INSERT INTO users (email, password, role, store_id) VALUES (?, ?, ?, ?)`,
      [email, hash, role, req.user.store_id],
      function(e) {
        if (e) return res.status(400).json({ error: "Erro ao criar usuário" });
        res.json({ id: this.lastID, email, role });
      }
    );
  });
});

app.get("/api/users", auth, adminOnly, (req, res) => {
  db.all(`SELECT id, email, role FROM users WHERE store_id = ?`, [req.user.store_id], (err, rows) => {
    if (err) return res.status(500).json({ error: "Erro ao listar usuários" });
    res.json(rows || []);
  });
});

// Products
app.get("/api/products", auth, (req, res) => {
  db.all(`SELECT id, name, price, stock FROM products WHERE store_id = ?`, [req.user.store_id], (err, rows) => {
    if (err) return res.status(500).json({ error: "Erro ao listar produtos" });
    res.json(rows || []);
  });
});

app.post("/api/products", auth, adminOnly, (req, res) => {
  const { name, price, stock } = req.body;
  if (!name) return res.status(400).json({ error: "Nome obrigatório" });
  db.run(`INSERT INTO products (name, price, stock, store_id) VALUES (?, ?, ?, ?)`, [name, price||0, stock||0, req.user.store_id], function(err) {
    if (err) return res.status(400).json({ error: "Erro ao adicionar produto" });
    res.json({ id: this.lastID, name, price, stock });
  });
});

// Orders (any authenticated user)
app.post("/api/orders", auth, (req, res) => {
  const { product_id, quantity } = req.body;
  if (!product_id || !quantity) return res.status(400).json({ error: "Campos obrigatórios" });
  db.get(`SELECT * FROM products WHERE id = ? AND store_id = ?`, [product_id, req.user.store_id], (err, product) => {
    if (err) return res.status(500).json({ error: "Erro no servidor" });
    if (!product) return res.status(400).json({ error: "Produto não encontrado" });
    if (product.stock < quantity) return res.status(400).json({ error: "Estoque insuficiente" });
    const total = product.price * quantity;
    const date = new Date().toISOString();
    db.run(`INSERT INTO orders (product_id, quantity, total, date, store_id) VALUES (?, ?, ?, ?, ?)`, [product_id, quantity, total, date, req.user.store_id]);
    db.run(`UPDATE products SET stock = stock - ? WHERE id = ?`, [quantity, product_id]);
    db.run(`INSERT INTO finance (type, description, amount, date, store_id) VALUES ('receita', ?, ?, ?, ?)`, [`Venda ${product.name}`, total, date, req.user.store_id]);
    res.json({ success: true, total });
  });
});

// Finance (admin only for list and add)
app.get("/api/finance", auth, adminOnly, (req, res) => {
  db.all(`SELECT id, type, description, amount, date FROM finance WHERE store_id = ? ORDER BY date DESC`, [req.user.store_id], (err, rows) => {
    if (err) return res.status(500).json({ error: "Erro ao listar financeiro" });
    res.json(rows || []);
  });
});

app.post("/api/finance", auth, adminOnly, (req, res) => {
  const { type, description, amount } = req.body;
  if (!type || !description || !amount) return res.status(400).json({ error: "Campos obrigatórios" });
  const date = new Date().toISOString();
  db.run(`INSERT INTO finance (type, description, amount, date, store_id) VALUES (?, ?, ?, ?, ?)`, [type, description, amount, date, req.user.store_id], function(err) {
    if (err) return res.status(400).json({ error: "Erro ao inserir lançamento" });
    res.json({ id: this.lastID, type, description, amount, date });
  });
});

// serve frontend
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`🚀 Servidor LA Uniformes rodando em http://localhost:${PORT}`));
